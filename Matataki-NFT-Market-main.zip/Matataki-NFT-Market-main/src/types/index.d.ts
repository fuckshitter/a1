declare module 'wavesurfer.js';
declare module 'react-copy-to-clipboard';
