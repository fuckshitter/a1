export class EventAt {
  blockNumber: number;
  timestamp: number;
  txHash: string;
}
