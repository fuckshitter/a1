import { User } from './User.types.d';

export interface WordItemState {
  a: User[];
  b: User[];
  c: User[];
  d: User[];
  e: User[];
  f: User[];
  g: User[];
  h: User[];
  i: User[];
  j: User[];
  k: User[];
  l: User[];
  m: User[];
  n: User[];
  o: User[];
  p: User[];
  q: User[];
  r: User[];
  s: User[];
  t: User[];
  u: User[];
  v: User[];
  w: User[];
  x: User[];
  y: User[];
  z: User[];
  '#': User[];
  [key: string]: User[];
}
