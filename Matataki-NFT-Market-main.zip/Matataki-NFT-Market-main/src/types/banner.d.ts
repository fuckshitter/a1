export type Banner = {
  id?: number;
  image: string;
  title: string;
  url: string;
};
