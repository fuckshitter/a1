export interface IconProps {
  /**
   * @deprecated Don't use
   */
  size?: number;
}

export { default as IconVerified } from './Verified';
export { default as IconClose } from './Close';
export { default as IconRespondArrow } from './RespondArrow';
