import React, { useState } from 'react';
import styled from 'styled-components';

const CurrencyTable: React.FC = () => {
  return null;
};

const CurrencyTableRoot = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: flex-start;
`;

export default CurrencyTable;
